const Router = artifacts.require("UniswapV2Router02.sol");
const WETL = artifacts.require("WETL.sol");

module.exports = async function (deployer, network, addresses) {
    const FACTORY_ADDRESS = "0xF7dFC06db5c3284D8e0819eE1fF0F30e3DbECd25";
    const wetl = await WETL.at("0x4446fc4eb47f2f6586f9faab68b3498f86c07521");
    // await deployer.deploy(WETL);
    // const wetl = await WETL.deployed(); 


    await deployer.deploy(Router, FACTORY_ADDRESS, wetl.address)
};
